input =input("salam :")

if '\\n' in input :
    print("true")
else :
    print("falses")